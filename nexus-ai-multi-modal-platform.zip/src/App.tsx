import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, 
  Camera, 
  FileText, 
  Database as DbIcon, 
  Settings, 
  History, 
  ChevronRight, 
  Upload,
  Cpu,
  BarChart3,
  AlertCircle,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import Papa from 'papaparse';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { cn } from './utils/cn';

type Tab = 'vision' | 'nlp' | 'tabular' | 'experiments';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('vision');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [history, setHistory] = useState<any[]>([]);

  // Vision State
  const [image, setImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // NLP State
  const [nlpText, setNlpText] = useState('');
  const [nlpTask, setNlpTask] = useState<'summarize' | 'classify' | 'analyze'>('analyze');

  // Tabular State
  const [csvData, setCsvData] = useState<any[]>([]);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    try {
      const res = await fetch('/api/experiments');
      const data = await res.json();
      setHistory(data);
    } catch (err) {
      console.error('Failed to fetch history', err);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVisionPredict = async () => {
    if (!image) return;
    setLoading(true);
    try {
      const res = await fetch('/api/predict/vision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image }),
      });
      const data = await res.json();
      setResult(data.result);
      fetchHistory();
    } catch (err) {
      setResult('Error performing vision analysis');
    } finally {
      setLoading(false);
    }
  };

  const handleNlpPredict = async () => {
    if (!nlpText) return;
    setLoading(true);
    try {
      const res = await fetch('/api/predict/nlp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: nlpText, task: nlpTask }),
      });
      const data = await res.json();
      setResult(data.result);
      fetchHistory();
    } catch (err) {
      setResult('Error performing NLP analysis');
    } finally {
      setLoading(false);
    }
  };

  const handleCsvUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      Papa.parse(file, {
        header: true,
        dynamicTyping: true,
        complete: (results) => {
          setCsvData(results.data.slice(0, 100));
          if (results.meta.fields) setCsvHeaders(results.meta.fields);
        }
      });
    }
  };

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] font-sans selection:bg-[#141414] selection:text-[#E4E3E0]">
      {/* Sidebar Navigation */}
      <aside className="fixed left-0 top-0 h-full w-64 border-r border-[#141414] bg-[#E4E3E0] z-20">
        <div className="p-8 border-bottom border-[#141414]">
          <div className="flex items-center gap-3 mb-1">
            <Cpu className="w-6 h-6" />
            <h1 className="text-xl font-bold tracking-tighter uppercase">Nexus AI</h1>
          </div>
          <p className="text-[10px] font-mono opacity-50 uppercase tracking-widest">Multi-Modal Platform v1.0</p>
        </div>

        <nav className="mt-8 px-4 space-y-1">
          <NavItem 
            icon={<Camera className="w-4 h-4" />} 
            label="Vision Engine" 
            active={activeTab === 'vision'} 
            onClick={() => setActiveTab('vision')} 
          />
          <NavItem 
            icon={<FileText className="w-4 h-4" />} 
            label="NLP Processor" 
            active={activeTab === 'nlp'} 
            onClick={() => setActiveTab('nlp')} 
          />
          <NavItem 
            icon={<DbIcon className="w-4 h-4" />} 
            label="Tabular AutoML" 
            active={activeTab === 'tabular'} 
            onClick={() => setActiveTab('tabular')} 
          />
          <div className="pt-8 pb-2 px-4 text-[10px] font-mono opacity-30 uppercase tracking-widest">System</div>
          <NavItem 
            icon={<History className="w-4 h-4" />} 
            label="Experiments" 
            active={activeTab === 'experiments'} 
            onClick={() => setActiveTab('experiments')} 
          />
          <NavItem 
            icon={<Settings className="w-4 h-4" />} 
            label="Configuration" 
            active={false} 
            onClick={() => {}} 
          />
        </nav>

        <div className="absolute bottom-8 left-8 right-8">
          <div className="p-4 border border-[#141414] rounded-sm bg-white/50">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-mono uppercase tracking-wider">System Online</span>
            </div>
            <div className="text-[9px] font-mono opacity-50 leading-tight">
              LATENCY: 42ms<br />
              UPTIME: 99.9%
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="pl-64 min-h-screen">
        <header className="h-20 border-b border-[#141414] flex items-center justify-between px-12 bg-[#E4E3E0]/80 backdrop-blur-sm sticky top-0 z-10">
          <div className="flex items-center gap-4">
            <span className="text-[11px] font-serif italic opacity-50 uppercase tracking-widest">Active Module</span>
            <ChevronRight className="w-3 h-3 opacity-30" />
            <span className="text-sm font-bold uppercase tracking-tight">
              {activeTab === 'vision' && 'Vision Analysis Engine'}
              {activeTab === 'nlp' && 'Natural Language Processor'}
              {activeTab === 'tabular' && 'Tabular Data AutoML'}
              {activeTab === 'experiments' && 'Experiment Tracking Logs'}
            </span>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="flex flex-col items-end">
              <span className="text-[10px] font-mono opacity-50 uppercase">Model Instance</span>
              <span className="text-xs font-bold">GEMINI-3-FLASH</span>
            </div>
            <div className="w-px h-8 bg-[#141414] opacity-10" />
            <button className="p-2 hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors">
              <Activity className="w-5 h-5" />
            </button>
          </div>
        </header>

        <div className="p-12 max-w-6xl mx-auto">
          <AnimatePresence mode="wait">
            {activeTab === 'vision' && (
              <motion.div 
                key="vision"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-1 lg:grid-cols-2 gap-12"
              >
                <section className="space-y-8">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-serif italic tracking-tight">Image Analysis</h2>
                    <p className="text-sm opacity-60">Upload an image for object detection and semantic captioning.</p>
                  </div>

                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className={cn(
                      "aspect-video border-2 border-dashed border-[#141414]/20 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-[#141414] transition-all overflow-hidden group relative",
                      image && "border-solid border-[#141414]/10"
                    )}
                  >
                    {image ? (
                      <>
                        <img src={image} className="w-full h-full object-cover" alt="Preview" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                          <span className="text-xs font-mono uppercase tracking-widest">Change Image</span>
                        </div>
                      </>
                    ) : (
                      <>
                        <Upload className="w-8 h-8 mb-4 opacity-20" />
                        <span className="text-xs font-mono uppercase tracking-widest opacity-40">Drop image or click</span>
                      </>
                    )}
                    <input 
                      type="file" 
                      ref={fileInputRef} 
                      onChange={handleImageUpload} 
                      className="hidden" 
                      accept="image/*" 
                    />
                  </div>

                  <button 
                    disabled={!image || loading}
                    onClick={handleVisionPredict}
                    className="w-full h-14 bg-[#141414] text-[#E4E3E0] rounded-xl font-bold uppercase tracking-widest text-xs flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed hover:scale-[1.01] active:scale-[0.99] transition-all"
                  >
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Camera className="w-4 h-4" />}
                    Run Inference
                  </button>
                </section>

                <section className="bg-white/50 border border-[#141414]/10 rounded-2xl p-8 min-h-[400px]">
                  <div className="flex items-center justify-between mb-6">
                    <span className="text-[10px] font-mono uppercase tracking-widest opacity-40">Output Console</span>
                    {loading && <span className="text-[10px] font-mono text-emerald-600 animate-pulse">Processing...</span>}
                  </div>
                  
                  {result ? (
                    <div className="prose prose-sm max-w-none">
                      <Markdown>{result}</Markdown>
                    </div>
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center opacity-20 italic font-serif">
                      Waiting for input...
                    </div>
                  )}
                </section>
              </motion.div>
            )}

            {activeTab === 'nlp' && (
              <motion.div 
                key="nlp"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-12"
              >
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                  <div className="lg:col-span-2 space-y-6">
                    <div className="space-y-2">
                      <h2 className="text-3xl font-serif italic tracking-tight">Text Intelligence</h2>
                      <p className="text-sm opacity-60">Paste text for summarization, sentiment, and classification.</p>
                    </div>
                    <textarea 
                      value={nlpText}
                      onChange={(e) => setNlpText(e.target.value)}
                      placeholder="Enter text to analyze..."
                      className="w-full h-64 bg-white/50 border border-[#141414]/10 rounded-2xl p-6 focus:outline-none focus:border-[#141414] transition-all resize-none font-mono text-sm"
                    />
                  </div>

                  <div className="space-y-6">
                    <div className="p-6 bg-white/50 border border-[#141414]/10 rounded-2xl space-y-4">
                      <span className="text-[10px] font-mono uppercase tracking-widest opacity-40">Task Selection</span>
                      <div className="space-y-2">
                        <TaskOption 
                          label="Summarize" 
                          active={nlpTask === 'summarize'} 
                          onClick={() => setNlpTask('summarize')} 
                        />
                        <TaskOption 
                          label="Classify & Sentiment" 
                          active={nlpTask === 'classify'} 
                          onClick={() => setNlpTask('classify')} 
                        />
                        <TaskOption 
                          label="Deep Analysis" 
                          active={nlpTask === 'analyze'} 
                          onClick={() => setNlpTask('analyze')} 
                        />
                      </div>
                    </div>

                    <button 
                      disabled={!nlpText || loading}
                      onClick={handleNlpPredict}
                      className="w-full h-14 bg-[#141414] text-[#E4E3E0] rounded-xl font-bold uppercase tracking-widest text-xs flex items-center justify-center gap-3 disabled:opacity-50 hover:scale-[1.01] transition-all"
                    >
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
                      Process Text
                    </button>
                  </div>
                </div>

                {result && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-white border border-[#141414]/10 rounded-2xl p-12 shadow-sm"
                  >
                    <div className="flex items-center gap-2 mb-8">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#141414]" />
                      <span className="text-[10px] font-mono uppercase tracking-widest">Analysis Result</span>
                    </div>
                    <div className="prose prose-lg max-w-none">
                      <Markdown>{result}</Markdown>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            )}

            {activeTab === 'tabular' && (
              <motion.div 
                key="tabular"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-12"
              >
                <div className="flex items-end justify-between">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-serif italic tracking-tight">Tabular AutoML</h2>
                    <p className="text-sm opacity-60">Upload CSV data for automated feature analysis and visualization.</p>
                  </div>
                  <label className="h-12 px-6 bg-[#141414] text-[#E4E3E0] rounded-xl font-bold uppercase tracking-widest text-[10px] flex items-center justify-center gap-3 cursor-pointer hover:scale-[1.02] transition-all">
                    <Upload className="w-4 h-4" />
                    Upload CSV
                    <input type="file" className="hidden" accept=".csv" onChange={handleCsvUpload} />
                  </label>
                </div>

                {csvData.length > 0 ? (
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-8">
                      <div className="bg-white border border-[#141414]/10 rounded-2xl p-8 overflow-x-auto">
                        <span className="text-[10px] font-mono uppercase tracking-widest opacity-40 block mb-6">Data Preview (First 5 Rows)</span>
                        <table className="w-full text-left text-xs font-mono">
                          <thead>
                            <tr className="border-b border-[#141414]/10">
                              {csvHeaders.map(h => <th key={h} className="pb-4 pr-4 uppercase opacity-50">{h}</th>)}
                            </tr>
                          </thead>
                          <tbody>
                            {csvData.slice(0, 5).map((row, i) => (
                              <tr key={i} className="border-b border-[#141414]/5 last:border-0">
                                {csvHeaders.map(h => <td key={h} className="py-3 pr-4">{String(row[h])}</td>)}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      <div className="bg-white border border-[#141414]/10 rounded-2xl p-8">
                        <span className="text-[10px] font-mono uppercase tracking-widest opacity-40 block mb-8">Feature Distribution</span>
                        <div className="h-[300px]">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={csvData.slice(0, 20)}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#14141410" />
                              <XAxis dataKey={csvHeaders[0]} tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                              <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                              <Tooltip 
                                contentStyle={{ backgroundColor: '#141414', border: 'none', borderRadius: '8px', color: '#E4E3E0' }}
                                itemStyle={{ fontSize: '10px', fontFamily: 'monospace' }}
                              />
                              <Bar dataKey={csvHeaders[1]} fill="#141414" radius={[4, 4, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-8">
                      <div className="bg-[#141414] text-[#E4E3E0] rounded-2xl p-8 space-y-6">
                        <div className="flex items-center gap-2">
                          <BarChart3 className="w-4 h-4" />
                          <span className="text-[10px] font-mono uppercase tracking-widest">AutoML Insights</span>
                        </div>
                        <div className="space-y-4">
                          <InsightItem label="Total Records" value={csvData.length} />
                          <InsightItem label="Features Detected" value={csvHeaders.length} />
                          <InsightItem label="Missing Values" value="0.4%" />
                          <InsightItem label="Task Type" value="Classification" />
                        </div>
                        <div className="pt-4">
                          <button className="w-full h-12 border border-[#E4E3E0]/20 rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-[#E4E3E0] hover:text-[#141414] transition-all">
                            Generate Report
                          </button>
                        </div>
                      </div>

                      <div className="bg-white border border-[#141414]/10 rounded-2xl p-8 space-y-4">
                        <div className="flex items-center gap-2 opacity-40">
                          <AlertCircle className="w-4 h-4" />
                          <span className="text-[10px] font-mono uppercase tracking-widest">Data Health</span>
                        </div>
                        <div className="space-y-3">
                          <div className="h-1.5 w-full bg-[#141414]/5 rounded-full overflow-hidden">
                            <div className="h-full w-[92%] bg-emerald-500" />
                          </div>
                          <p className="text-[10px] opacity-60 leading-relaxed">
                            Data quality is high. No significant outliers detected in the primary features.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="h-[400px] border-2 border-dashed border-[#141414]/10 rounded-3xl flex flex-col items-center justify-center space-y-4 opacity-30">
                    <DbIcon className="w-12 h-12" />
                    <p className="font-serif italic">Upload a CSV file to begin automated analysis</p>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'experiments' && (
              <motion.div 
                key="experiments"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-8"
              >
                <div className="space-y-2">
                  <h2 className="text-3xl font-serif italic tracking-tight">Experiment Logs</h2>
                  <p className="text-sm opacity-60">Historical tracking of all model inferences and data runs.</p>
                </div>

                <div className="bg-white border border-[#141414]/10 rounded-2xl overflow-hidden">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="bg-[#141414]/5 text-[10px] font-mono uppercase tracking-widest">
                        <th className="p-6">ID</th>
                        <th className="p-6">Type</th>
                        <th className="p-6">Input Summary</th>
                        <th className="p-6">Timestamp</th>
                        <th className="p-6 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="text-sm">
                      {history.map((exp) => (
                        <tr key={exp.id} className="border-b border-[#141414]/5 hover:bg-[#141414]/[0.02] transition-colors">
                          <td className="p-6 font-mono text-xs opacity-40">#{String(exp.id).padStart(4, '0')}</td>
                          <td className="p-6">
                            <span className={cn(
                              "px-2 py-1 rounded-sm text-[9px] font-bold uppercase tracking-wider",
                              exp.type === 'vision' ? "bg-blue-100 text-blue-700" : "bg-purple-100 text-purple-700"
                            )}>
                              {exp.type}
                            </span>
                          </td>
                          <td className="p-6 font-medium truncate max-w-xs">{exp.input_summary}</td>
                          <td className="p-6 opacity-50 text-xs">{new Date(exp.timestamp).toLocaleString()}</td>
                          <td className="p-6 text-right">
                            <button className="text-[10px] font-bold uppercase tracking-widest opacity-40 hover:opacity-100 transition-opacity">
                              View Details
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {history.length === 0 && (
                    <div className="p-12 text-center opacity-30 italic font-serif">
                      No experiments logged yet.
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all group",
        active ? "bg-[#141414] text-[#E4E3E0]" : "hover:bg-[#141414]/5"
      )}
    >
      <span className={cn("transition-transform group-hover:scale-110", active ? "opacity-100" : "opacity-40")}>
        {icon}
      </span>
      <span className={cn("text-xs font-bold uppercase tracking-widest", !active && "opacity-60")}>
        {label}
      </span>
      {active && (
        <motion.div 
          layoutId="nav-active"
          className="ml-auto w-1.5 h-1.5 rounded-full bg-[#E4E3E0]"
        />
      )}
    </button>
  );
}

function TaskOption({ label, active, onClick }: { label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full text-left px-4 py-3 rounded-xl text-[11px] font-bold uppercase tracking-widest border transition-all",
        active ? "bg-[#141414] text-[#E4E3E0] border-[#141414]" : "bg-transparent border-[#141414]/10 opacity-60 hover:opacity-100"
      )}
    >
      {label}
    </button>
  );
}

function InsightItem({ label, value }: { label: string, value: string | number }) {
  return (
    <div className="flex items-center justify-between border-b border-[#E4E3E0]/10 pb-3">
      <span className="text-[10px] font-mono opacity-50 uppercase">{label}</span>
      <span className="text-xs font-bold">{value}</span>
    </div>
  );
}
